<div><div><div class="container">
								<!--begin::Card-->
								<div class="card card-custom">
									<div class="card-header flex-wrap border-0 pt-6 pb-0">
										<div class="card-title">
											<h3 class="card-label">
											Lukins Failure Products</h3> 
										</div>
										<div class="card-toolbar">
										
											
											
											
												
												<button class="btn btn-sm btn-success mr-2" type="button" id="kt_datatable_pulish_all" style="font-weight: 600 !important;padding: 0.65rem 1rem;font-size: 1rem;line-height: 1.5;">Publish All</button>
												<button class="btn btn-sm btn-primary mr-2" type="button" id="kt_datatable_UnPublish_all" style="font-weight: 600 !important;padding: 0.65rem 1rem;font-size: 1rem;line-height: 1.5;">UnPublish All</button>
												<button class="btn btn-sm btn-danger mr-2" type="button" id="kt_datatable_delete_all" style="color: #ffffff;background-color: #F64E60;border-color: #F64E60;font-weight: 600 !important;padding: 0.65rem 1rem;font-size: 1rem;line-height: 1.5;">Delete All</button>
												<button class="btn btn-sm mr-2" type="button" id="kt_datatable_delete_all" style="color: #ffffff;font-weight: 600 !important;padding: 0.50rem 2.7rem;font-size: 1rem;line-height: 1.5;display:none"><i class="fa fa-spinner fa-spin" style="font-size:24px;color:red"></i></button>
												<li class="li-file secli" style="margin-left:10px;display:none"><i class="fa fa-spinner fa-spin" style="font-size:24px;color:red"></i></li>
											
											
										</div>
									</div>
									<div class="card-body">
										<!--begin: Search Form-->
										<!--begin::Search Form-->
										<div class="mb-7">
											<div class="row align-items-center">
												<div class="col-lg-9 col-xl-8">
													<div class="row align-items-center">
														<div class="col-md-4 my-2 my-md-0">
															<div class="input-icon">
																<input type="text" class="form-control" placeholder="Search..." id="kt_datatable_search_query" />
																<span>
																	<i class="flaticon2-search-1 text-muted"></i>
																</span>
															</div>
														</div>
														<div class="col-md-4 my-2 my-md-0">
															<div class="d-flex align-items-center">
																<label class="mr-3 mb-0 d-none d-md-block">Manufacture</label>
																<select class="form-control" id="kt_datatable_search_status">
																	<option value="">All</option>
																	
																</select>
															</div>
														</div>
														<div class="col-md-4 my-2 my-md-0">
															<div class="d-flex align-items-center">
																<label class="mr-3 mb-0 d-none d-md-block">Category</label>
																<select class="form-control" id="kt_datatable_search_type">
																	<option value="">All</option>
																	
																	
																</select>
															</div>
														</div>
													</div>
												</div>
												
												
											</div>
										</div>
										<!--end::Search Form-->
										<!--end: Search Form-->
										<!--begin: Datatable-->
										
										<!--end: Datatable-->
									</div>
									
								</div>
								<!--end::Card-->
							</div>
							<!--end::Container-->
						</div>
						<!--end::Entry-->
					</div>
					
					<!--end::Content-->
				
					
				<div class="form_part" style="margin-top: 24px;">
<div class="container">
								<div class="card card-custom">
									
									<div class="card-body">
										
										<div class="mb-7">
											<div class="datatable datatable-bordered datatable-head-custom printable" id="kt_datatable"></div>
											
										</div>
									
									</div>
								</div>
				</div>
							</div>

							
<script>
  $('#updatecsvjax').change(function(){
			 $('#sendupdatecsv').submit();  
			  
		   });
</script>