

			<div id="form">
				<div class="container">
					 
						<div class="row">
							<div class="col-md-6 col-xs-12">
							<div class="card card-custom gutter-b example example-compact">
							<div class="card-header">
                        <h3 class="card-title">General Details</h3>

                    </div>
					
					<div class="card-body">
                        <div class="dropzone" style="border: none;">
                            <div class="jumbotron-sec marg ">

                                <div class="form-horizontal">
                                    <div class="form-group">
						  
								 <form method="post" enctype="multipart/form-data" action="<?php echo site_url('InsertCatList');?>">
								   <label>Category List Name</label>
									<input type="text" name="catlist" class="form-control form-control-solid">
									<input style="margin-top: 10px;" type="submit" value="Add" name="categorylistbutton" class="btn btn-info listbtn">
								  </form>
							
							</div>
							
							
							
							
							</div>
						</div>
						</div>
						</div>
						</div>
					
							
							</div>
						</div>

				 <!-- </form>-->
				<hr>
				</div>
			</div>
	
<