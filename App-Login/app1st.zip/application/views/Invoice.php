<div>
<div><div class="container">
						
								<div class="card card-custom">
									<div class="card-header flex-wrap border-0 pt-6 pb-0">
									<h5 class="text-dark font-weight-bold my-1 mr-5">Invoices</h5>
									<!-- card tabs
									<div class="new_tabs_invoices" style="width:100%;padding-bottom:2em;">
<div class="container" style="padding:0px"> 
    <div class="row">
	     <div class="new_tabs_invoices_col" style="flex:1"> <a href="<?php base_url()?>/Invoice" class="new_tabs_anchor"  style="padding: 1rem;border: none;background: #134798;;width: 100%;display: block;text-align: center;color: #fff;font-size: 17px;">Invoices</a></div>
	     <div class="new_tabs_invoices_col" style="flex:1"> <a href="<?php base_url()?>/Quotation" class="new_tabs_anchor"  style="padding: 1rem;border: none;background: #242939;width: 100%;display: block;text-align: center;color: #fff;font-size: 17px;">Quotes</a></div>
	     <div class="new_tabs_invoices_col" style="flex:1"> <a href="<?php base_url()?>/Creditnote" class="new_tabs_anchor"  style="padding: 1rem;border: none;background: #242939;width: 100%;display: block;text-align: center;color: #fff;font-size: 17px;">Credit notes</a></div>
	     <div class="new_tabs_invoices_col" style="flex:1"> <a href="#" class="new_tabs_anchor"  style="padding: 1rem;border: none;background: #242939;width: 100%;display: block;text-align: center;color: #fff;font-size: 17px;">Statements </a></div>
	     <div class="new_tabs_invoices_col" style="flex:1"> <a href="<?php base_url()?>/SetUp" class="new_tabs_anchor"  style="padding: 1rem;border: none;background: #242939;width: 100%;display: block;text-align: center;color: #fff;font-size: 17px;">Set up </a></div>
	     <div class="new_tabs_invoices_col" style="flex:1"> <a href="#" class="new_tabs_anchor"  style="padding: 1rem;border: none;background: #242939;width: 100%;display: block;text-align: center;color: #fff;font-size: 17px;">Reports</a></div>
	</div>
</div>
</div> -->

<!-- card tabs -->
									
										<div class="card-title">
											
										</div>
										<div class="card-toolbar">
										
										</div>
									</div>
									<div class="card-body">
										
										<div class="mb-7">
											<div class="row align-items-center">
												<div class="col-lg-12 col-xl-12">
													<div class="row align-items-center">
														<div class="col-md-3 my-2 my-md-0">
															<div class="input-icon">
																<input type="text" class="form-control" placeholder="Search..." id="kt_datatable_search_query" />
																<span>
																	<i class="flaticon2-search-1 text-muted"></i>
																</span>
															</div>
														</div>
														<!--<div class="col-md-3 my-2 my-md-0">
															<div class="d-flex align-items-center">
																<label class="mr-3 mb-0 d-none d-md-block">Supplier  Name</label>
																<select class="form-control" id="kt_datatable_search_status">
																	<option value="">All</option>
																																		
																	
																	
																		<option value="Vender  name ">vender name</option>
																	           
																	 
																</select>
															</div>
														</div>-->
														
														
														<div class="col-md-3 my-2 my-md-0">
															<div class="d-flex align-items-center">
																<label class="mr-3 mb-0 d-none d-md-block">Month</label>
																<select class="form-control" id="kt_datatable_search_month">  
																	<option value="">All</option>
																	<option value="01">January</option>
																	<option value="02">February </option>
																	<option value="03">March </option>
																	<option value="04">April  </option>
																	<option value="05">May</option>
																	<option value="06">June  </option>
																	<option value="07">July </option>
																	<option value="08">August </option>
																	<option value="09">September</option>
																	<option value="10">October  </option>
																	<option value="11">November</option>
																	<option value="12">December </option>
																	
																	
																	
																		
																	           
																	 
																</select>
															</div>
														</div>
														
														
														
														
														
													</div>
												</div>
												
											</div>
										</div>
										
									</div>
									
								</div>
							
							</div>
							
						</div>
					
					</div>
					
					
				
					
				<div class="form_part" style="margin-top: 24px;">
<div class="container">
								<div class="card card-custom">
									
									<div class="card-body">
										
										<div class="mb-7">
											<div class="datatable datatable-bordered datatable-head-custom printable" id="kt_datatable"></div>
											
										</div>
									
									</div>
								</div>
				</div>
							</div>

							
<script>
$("#kt_datatable_onclick").click(function(){
  
		   
		   alert("hello");
		   
		   
		   
	   });
</script>