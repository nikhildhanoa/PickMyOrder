<?php 
error_reporting(0); 
if($_SESSION['status']['iswholseller'])
{ 
	$type="Users";
	$business_id=$_SESSION['status']['business_id'];
}
else
{  
	$type="Engineers";
	$business_id=$_SESSION['status']['business_id'];
}
if($business_id)
{
$bussindata=$this->db->query("select business_name,Trial_business from dev_business where id=$business_id");
$bussinessname=$bussindata->result_array();
$thenaame=$bussinessname[0]['business_name'];
$Trial_business_status=$bussinessname[0]['Trial_business'];
}
else
{    
	$thenaame="TM8";    
}
?>

<!DOCTYPE html>
<!--
Template Name: Keen - The Ultimate Bootstrap 4 HTML Admin Dashboard Theme
Author: KeenThemes
Website: http://www.keenthemes.com/
Contact: support@keenthemes.com
Follow: www.twitter.com/keenthemes
Dribbble: www.dribbble.com/keenthemes
Like: www.facebook.com/keenthemes
Purchase: https://themes.getbootstrap.com/product/keen-the-ultimate-bootstrap-admin-theme/
Support: https://keenthemes.com/theme-support
License: You must have a valid license purchased only from themes.getbootstrap.com(the above link) in order to legally use the theme for your project.
-->
<html lang="en">
	<!--begin::Head-->
	<head><base href="../../">
		<meta charset="utf-8" />
		<title>TM8</title>
		<meta name="description" content="Draggable cards examples" />
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
		<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests"> 
		<!-------------------------------------------------------old css---------------------------------------->
		<link href="<?php echo base_url(); ?>/assets/vendors/custom/fullcalendar/fullcalendar.bundle.css" rel="stylesheet" type="text/css" />

		<!--end::Page Vendors Styles -->

		<!--begin:: Global Mandatory Vendors -->
		<link href="<?php echo base_url(); ?>/assets/vendors/general/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" type="text/css" />

		<!--end:: Global Mandatory Vendors -->

		<!--begin:: Global Optional Vendors -->
		<link href="<?php echo base_url(); ?>/assets/vendors/general/tether/dist/css/tether.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/bootstrap-datepicker/dist/css/bootstrap-datepicker3.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/bootstrap-datetime-picker/css/bootstrap-datetimepicker.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/bootstrap-timepicker/css/bootstrap-timepicker.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/bootstrap-select/dist/css/bootstrap-select.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/nouislider/distribute/nouislider.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/owl.carousel/dist/assets/owl.carousel.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/owl.carousel/dist/assets/owl.theme.default.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/dropzone/dist/dropzone.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/summernote/dist/summernote.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/bootstrap-markdown/css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/animate.css/animate.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/toastr/build/toastr.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/morris.js/morris.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/sweetalert2/dist/sweetalert2.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/socicon/css/socicon.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/custom/vendors/line-awesome/css/line-awesome.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/custom/vendors/flaticon/flaticon.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/custom/vendors/flaticon2/flaticon.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/vendors/general/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css" />

		<!--end:: Global Optional Vendors -->

		<!--begin::Global Theme Styles(used by all pages) -->
	<!--	<link href="<?php echo base_url(); ?>/assets/css/demo1/style.bundle.css" rel="stylesheet" type="text/css" />

		<!--end::Global Theme Styles -->

		<!--begin::Layout Skins(used by all pages) -->
		<link href="<?php echo base_url(); ?>/assets/css/demo1/skins/header/base/light.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/css/demo1/skins/header/menu/light.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/css/demo1/skins/brand/navy.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url(); ?>/assets/css/demo1/skins/aside/navy.css" rel="stylesheet" type="text/css" />

		<!--end::Layout Skins -->
		<link rel="shortcut icon" href="<?php echo base_url(); ?>/images/applogo/favicon_m8.png" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<!--begin::Page Vendors Styles(used by this page) -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
		<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
		<!------------------------------------>
       <link data-require="jqueryui" data-semver="1.10.0" rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jqueryui/1.10.0/css/smoothness/jquery-ui-1.10.0.custom.min.css" />
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="dragtable.css" />
    <script data-require="jquery" data-semver="1.9.1" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script data-require="jqueryui" data-semver="1.10.0" src="//cdnjs.cloudflare.com/ajax/libs/jqueryui/1.10.0/jquery-ui.js"></script>
    <script src="jquery.dragtable.js"></script>
   <!-- <script src="jquery.tablesorter.min.js"></script>
    <script src="script.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
	
	<script src="{{ asset('bundles/app/js/jquery-ui.js') }}"></script>
<script src="{{ asset('bundles/comurimage/js/jquery.ui.widget.js') }}"></script>-->
		<!-------------------------------rohit------------------------------------------------------------------->
		<!--begin::Fonts-->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
		<!--end::Fonts-->
		<!--begin::Global Theme Styles(used by all pages)-->
		
		<!--end::Global Theme Styles-->
		<!--begin::Layout Themes(used by all pages)-->
		<link href="NewThemeAssets/assets/css/themes/layout/header/base/light.css" rel="stylesheet" type="text/css" />
		<link href="NewThemeAssets/assets/css/themes/layout/header/menu/light.css" rel="stylesheet" type="text/css" />
		<link href="NewThemeAssets/assets/css/themes/layout/brand/dark.css" rel="stylesheet" type="text/css" />
		<link href="NewThemeAssets/assets/css/themes/layout/aside/dark.css" rel="stylesheet" type="text/css" />
		<!--end::Layout Themes-->
		<link rel="shortcut icon" href="https://app.pickmyorder.co.uk//images/applogo/Favicon_new_2.ico" type="image/x-icon"/>
		<link rel="shortcut icon" href="NewThemeAssets/my_custom_css.css" />.
		<link href="NewThemeAssets/assets/plugins/global/plugins.bundle.css" rel="stylesheet" type="text/css" />
		<link href="NewThemeAssets/assets/plugins/custom/prismjs/prismjs.bundle.css" rel="stylesheet" type="text/css" />
		<link href="NewThemeAssets/assets/css/style.bundle.css" rel="stylesheet" type="text/css" />
		<style>
			.placholder_class input::placeholder{
	color: red;
} 
.titles{
	color:red;
}
span.titles {
    padding: 14px;
}
div>label.col-md-6 {
	margin-bottom: 0px;
    margin-top: 10px;
}
h3.font-size-lg.text-dark.font-weight-bold.mb-6 {
	padding: 16px 0 16px 10px !important;
}

.checks{

    border-color: transparent;
    border-style: solid;
 
}
.trial_period_experied{
	    z-index: 1111;
    position: absolute;
    top: 83px;
	right:140px;
    color: red;
    font-size: 16px;
}
.header{
	height:80px;
}
.trial_period_experied {
    z-index: 1111;
    position: absolute;
    top: 55px;
    right: 36%;
    color: red;
    font-size: 15px;
}
.publish{
	background-color: #1BC5BD;
border-color: transparent;
color: #fff;
padding: 0.4em 1.7em;
border-radius: 6px;
}
.unpublish{
	padding: 0.4em 1em;
border-radius: 6px;
color: #fff;
color: #ffffff;
background-color: #EE2D41;
}

.del_span{
color: #88c0fd;
width: 100%;
display: block;
text-align: center;
font-size: 14px;
border-radius: 4px;
padding: 1px;
}
.add_span{
	background-color: #7bae37;
color: #fff;
width: 100%;
display: block;
text-align: center;
font-size: 14px;
border-radius: 4px;
padding: 1px;
	
}
		</style>
	</head>
	<!--end::Head-->
	<!--begin::Body-->
	<body id="kt_body" class="quick-panel-right demo-panel-right offcanvas-right header-fixed header-mobile-fixed subheader-enabled aside-enabled aside-fixed aside-minimize-hoverable page-loading">
		<!--begin::Main-->
		<!--begin::Header Mobile-->
		<div id="kt_header_mobile" class="header-mobile align-items-center header-mobile-fixed">
			<!--begin::Logo-->
			<a href="index.html">
				<img alt="Logo" src="<?php echo base_url(); ?>assets/images/unnamed.png" />
			</a>
			<!--end::Logo-->
			<!--begin::Toolbar-->
			<div class="d-flex align-items-center">
				<!--begin::Aside Mobile Toggle-->
				<button class="btn p-0 burger-icon burger-icon-left" id="kt_aside_mobile_toggle">
					<span></span>
				</button>
				<!--end::Aside Mobile Toggle-->
				<!--begin::Header Menu Mobile Toggle-->
				<button class="btn p-0 burger-icon ml-5" id="kt_header_mobile_toggle">
					<span></span>
				</button>
				<!--end::Header Menu Mobile Toggle-->
				<!--begin::Topbar Mobile Toggle-->
				<button class="btn btn-hover-text-primary p-0 ml-3" id="kt_header_mobile_topbar_toggle">
					<span class="svg-icon svg-icon-xl">
						<!--begin::Svg Icon | path:themeCustomization/NewThemeAssets/assets/media/svg/icons/General/User.svg-->
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
							<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
								<polygon points="0 0 24 0 24 24 0 24" />
								<path d="M12,11 C9.790861,11 8,9.209139 8,7 C8,4.790861 9.790861,3 12,3 C14.209139,3 16,4.790861 16,7 C16,9.209139 14.209139,11 12,11 Z" fill="#000000" fill-rule="nonzero" opacity="0.3" />
								<path d="M3.00065168,20.1992055 C3.38825852,15.4265159 7.26191235,13 11.9833413,13 C16.7712164,13 20.7048837,15.2931929 20.9979143,20.2 C21.0095879,20.3954741 20.9979143,21 20.2466999,21 C16.541124,21 11.0347247,21 3.72750223,21 C3.47671215,21 2.97953825,20.45918 3.00065168,20.1992055 Z" fill="#000000" fill-rule="nonzero" />
							</g>
						</svg>
						<!--end::Svg Icon-->
					</span>
				</button>
				<!--end::Topbar Mobile Toggle-->
			</div>
			<!--end::Toolbar-->
		</div>
		<!--end::Header Mobile-->
		<div class="d-flex flex-column flex-root">
			<!--begin::Page-->
			<div class="d-flex flex-row flex-column-fluid page">
				
		
				<!--begin::Wrapper-->
				<div class="d-flex flex-column flex-row-fluid wrapper" id="kt_wrapper">
					<!--begin::Header-->
					<div id="kt_header" class="header header-fixed">
					     <div class="container-fluid d-flex align-items-center" id="kt_header_menu_wrapper">
						 
						 
						 
						 
						<?php if(isset($_SESSION['status'])){ if($_SESSION['status']['role']=='1') {?>
							<div id="kt_header_menu" class="mr-5" style="
    width: 180px;
">
							<?php $Get_Data_object = $this->db->query("select * from dev_business where iswholeapp='0' order by in_order desc ,business_name"); 
							  $Get_Data = $Get_Data_object->result_array(); ?>
							   
							<Select class="select_business form-control form-control-solid" ><option value="0">Contractors Apps</option><?php foreach($Get_Data as $Data) { ?>
							
							
							<option class="test" value="<?= $Data['id'];?>" <?php if(isset($_SESSION['Current_Business'])){if($Data['id']==$_SESSION['Current_Business']){?> selected <?php }} ?> ><?= $Data['business_name']; ?></option>
							<?php } ?></select>
								
								</ul>
							</div>
							<div id="kt_header_menu2" class="mr-5" style="width: 180px;">
    

							<?php $Get_Data_object = $this->db->query("select * from dev_business where iswholeapp='1'"); 
							   $Get_Data=$Get_Data_object->result_array();
							?>
							
							<Select class="select_business repeatselect form-control form-control-solid" ><option value="0">Wholesaler Apps</option><?php foreach($Get_Data as $Data) { ?>
							
							<option value="<?= $Data['id'];?>" <?php if(isset($_SESSION['Current_Business'])){if($Data['id']==$_SESSION['Current_Business']){?> selected <?php }} ?> ><?= $Data['business_name']; ?></option>
							<?php } ?></select>
								
								</ul>
							</div>
						
						
						<div id="kt_header_menu2" style="width: 180px;">
    
                          <?php $Get_Data_object = $this->db->query("select * from dev_business where iswholeapp='3'"); 
							   $Get_Data=$Get_Data_object->result_array();
							?>
							
							
							<Select class="select_business repeatselect form-control form-control-solid" ><option value="0">Brand Business</option> <?php foreach($Get_Data as $Data) { ?>
							<option value="<?= $Data['id'];?>" <?php if(isset($_SESSION['Current_Business'])){if($Data['id']==$_SESSION['Current_Business']){?> selected <?php }} ?> ><?= $Data['business_name']; ?></option>
							<?php } ?></select>
							
							
							</select>
								
								</ul>
							</div>
						<?php } } ?>
						
						</div>
						
						<!--begin::Container-->
						<div class="container-fluid d-flex align-items-stretch justify-content-between">
							<!--begin::Header Menu Wrapper-->
							<div class="header-menu-wrapper header-menu-wrapper-left" id="kt_header_menu_wrapper">
								<!--begin::Header Menu-->
								<div id="kt_header_menu" class="header-menu header-menu-mobile header-menu-layout-default">
									<!--begin::Header Nav-->
									<ul class="menu-nav">
					               
									</ul>
									<!--end::Header Nav-->
								</div>
								<!--end::Header Menu-->
							</div>
							<!--end::Header Menu Wrapper-->
							<!--begin::Topbar-->
							
						<div class="topbar">
						
							
							
								<div class="dropdown mr-1" >
							
								
									<div class="topbar-item"  data-offset="10px,0px">
										<div >
								

									<h5><?php echo $thenaame.' ';  if(isset($_SESSION['status'])){ if($_SESSION['status']['role']=='2') { echo "Admin";  }else{ echo "Super Admin";}}?> </h5>
									
										<!--<span class="kt-header__topbar-welcome kt-hidden-mobile">Hi <?php if(isset($_SESSION['status'])){ echo ucfirst($_SESSION['status']['name']); }?></span>-->
										

										
										
									
									<span>Welcome <b><?php if(isset($_SESSION['status'])){ echo ucfirst($_SESSION['status']['name']); }?></b></span> | <span><?php echo date('M d Y');?></span> | <a href="<?php echo site_url('logout'); ?>">Logout</a> | <a href="<?php echo base_url();?>"><i class="fa fa-globe" aria-hidden="true"></i></a>
								
								
							</div>
									</div>
								
									
								
								</div>
								
							
								
								
							</div>
							<!--end::Topbar-->
						</div>
						<!--end::Container-->
					</div>
					<!--end::Header-->
					