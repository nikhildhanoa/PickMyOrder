<div>
<div><div class="container">
						
								<div class="card card-custom">
									<div class="card-header flex-wrap border-0 pt-6 pb-0">
									
									<!-- card tabs -->
								
<!-- card tabs -->
									
										<div class="card-title">
											
										</div>
										<div class="card-toolbar">
										
										</div>
									</div>
									<div class="card-body">
										
										<div class="mb-7">
											<div class="row align-items-center">
												<div class="col-lg-12 col-xl-12">
													<div class="row align-items-center">
														<div class="col-md-3 my-2 my-md-0">
															<div class="input-icon">
																<input type="text" class="form-control" placeholder="Search..." id="kt_datatable_search_query" />
																<span>
																	<i class="flaticon2-search-1 text-muted"></i>
																</span>
															</div>
														</div>
														<div class="col-md-3 my-2 my-md-0">
															<div class="d-flex align-items-center">
																<label class="mr-3 mb-0 d-none d-md-block">Vender Name</label>
																<select class="form-control" id="kt_datatable_search_status">
																	<option value="">All</option>
																																		
																	
																	
																		<option value="Vender  name ">vender name</option>
																	           
																	 
																</select>
															</div>
														</div>
														
														
														
														
														
														
													</div>
												</div>
												
											</div>
										</div>
										
									</div>
									
								</div>
							
							</div>
							
						</div>
					
					</div>
					
					
				
					
				<div class="form_part" style="margin-top: 24px;">
<div class="container">
								<div class="card card-custom">
									
									<div class="card-body">
										
										<div class="mb-7">
											<div class="datatable datatable-bordered datatable-head-custom printable" id="kt_datatable"></div>
											
										</div>
									
									</div>
								</div>
				</div>
							</div>

							
<script>
$("#kt_datatable_onclick").click(function(){
  
		   
		   alert("hello");
		   
		   
		   
	   });
</script>