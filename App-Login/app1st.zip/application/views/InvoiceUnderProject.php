<div>
<div><div class="container">
						
								<div class="card card-custom">
									<div class="card-header flex-wrap border-0 pt-6 pb-0">
									<h5 class="text-dark font-weight-bold my-1 mr-5">Invoices Under Project</h5>
										
										<div class="card-title">
											
										</div>
										<div class="card-toolbar">
										
										</div>
									</div>
									<div class="card-body">
										
										<div class="mb-7">
											<div class="row align-items-center">
												<div class="col-lg-12 col-xl-12">
													<div class="row align-items-center">
														<div class="col-md-3 my-2 my-md-0">
															<div class="input-icon">
																<input type="text" class="form-control" placeholder="Search..." id="kt_datatable_search_query" />
																<span>
																	<i class="flaticon2-search-1 text-muted"></i>
																</span>
															</div>
														</div>
														
														
														<div class="col-md-3 my-2 my-md-0">
															<div class="d-flex align-items-center">
																<label class="mr-3 mb-0 d-none d-md-block">Month</label>
																<select class="form-control" id="kt_datatable_search_month">  
																	<option value="">All</option>
																	<option value="01">January</option>
																	<option value="02">February </option>
																	<option value="03">March </option>
																	<option value="04">April  </option>
																	<option value="05">May</option>
																	<option value="06">June  </option>
																	<option value="07">July </option>
																	<option value="08">August </option>
																	<option value="09">September</option>
																	<option value="10">October  </option>
																	<option value="11">November</option>
																	<option value="12">December </option>
																	
																	
																	
																		
																	           
																	 
																</select>
															</div>
														</div>
														
														
														
														
														
													</div>
												</div>
												
											</div>
										</div>
										
									</div>
									
								</div>
							
							</div>
							
						</div>
					
					</div>
					
					
				
					
				<div class="form_part" style="margin-top: 24px;">
<div class="container">
								<div class="card card-custom">
									
									<div class="card-body">
										
										<div class="mb-7">
											<div class="datatable datatable-bordered datatable-head-custom printable" id="kt_datatable"></div>
											
										</div>
									
									</div>
								</div>
				</div>
							</div>

			<script>
			
			
		 $('#cars').on('change', function() {
            alert("hello");
        });
		 
			
			</script>