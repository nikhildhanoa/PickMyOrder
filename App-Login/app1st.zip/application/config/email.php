<?php  
$config = array();
		$config['protocol']     = "smtp"; // you can use 'mail' instead of 'sendmail or smtp'
		$config['smtp_host']    = "smtp.hostinger.com";
		$config['smtp_user']    = "Admin@tradesm8.com"; // client email gmail id
		$config['smtp_pass']    = "An0therTry!"; // client password
		$config['smtp_port']    =  465;
		$config['smtp_crypto']  = 'ssl';
		$config['smtp_timeout'] = 8;
	    $config['mailpath'] = '/usr/sbin/sendmail';
		$config['mailtype']     = "html";
		$config['charset']      = "iso-8859-1";
		$config['newline']      = "\r\n";
		$config['wordwrap']     = TRUE;
		$config['validate']     = FALSE;	
		/* $this->email->initialize($config);
		$this->email->set_mailtype("html");
		$this->email->set_newline("\r\n"); */


?>